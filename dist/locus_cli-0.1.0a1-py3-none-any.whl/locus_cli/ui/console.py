# Rich will read the properties of the console being used and optimize the 
# use of colors everywhere when it is used in other parts of the project
from rich.console import Console
console = Console()